package com.example.ch15_network.network

class News {
    var id: Long = 0
    var author: String? = null
    var title: String? = null
    var description: String? = null
    var urlToImage: String? = null
    var publishedAt: String? = null
}

class Page {
    var articles: MutableList<News>? = null
}